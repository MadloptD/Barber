/*tslint:disable interface-name*/
import {Time} from "./Time.g";

export interface JobSchedule {
    times: Time[];
}

