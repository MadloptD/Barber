/*tslint:disable interface-name*/

export interface LoginRequest {
    login: string;
    password: string;
}

