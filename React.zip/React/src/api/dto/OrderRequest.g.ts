/*tslint:disable interface-name*/

export interface OrderRequest {
    date: Date;
    serviceId: string;
}

