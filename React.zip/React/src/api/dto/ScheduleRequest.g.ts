/*tslint:disable interface-name*/

export interface ScheduleRequest {
    serviceId: string;
    date: Date;
}

