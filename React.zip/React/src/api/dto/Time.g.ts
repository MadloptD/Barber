/*tslint:disable interface-name*/

export interface Time {
    value: number;
    free: boolean;
}

